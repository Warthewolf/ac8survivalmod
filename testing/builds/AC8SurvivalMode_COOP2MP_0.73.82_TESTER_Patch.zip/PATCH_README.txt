AC8 Survival Mode COOP2MP 0.73.82 - TESTER patch (for Saint Alessia only, 2026-11-04)
======================================================================================
Test keys in (the same keys as your 0.73.78 key list). Please don't pass this one on: your joiners use
AC8SurvivalMode_COOP2MP_0.73.82_Patch.zip (same version, so you link fine).

For: a 0.73.78 COOP2MP Online COOP install, with or without the 0.73.79 - 0.73.81 patches (this one replaces every Lua
file and config\survival.default.ini). Everything in 0.73.81's change log is in it too.

What's new since 0.73.81:
- Crash on launch fixed (Saint Alessia, 2026-11-04): when the main menu took a long time to load (54 s on her PC),
  Survival's tick watchdog (added in 0.73.75) wrote to its logs and queued extra ticks from UE4SS's background thread
  while the game thread was busy running the ticks it had missed. The script engine can't run on two threads at once,
  and the game crashed. That background function now only reads two flags and the clock and queues the next tick;
  anything to report is logged by the tick itself, on the game thread. It queues nothing while a tick waits or runs,
  and during a long load it queues one more tick after 10 s, then after 20 s, 40 s and so on (it used to add one every
  10 s).
- Key presses run on the game thread too. UE4SS runs key binds on its own input thread, and every Survival key then did
  work there. Now a press only adds 1 to a counter on that thread, and the next tick (within 1/8 s) runs the key's
  action. Every key works as before, just up to 1/8 s later. A key pressed more than 4 times between two ticks runs 4
  times.

Install (the game closed):
  Copy the "ue4ss" folder from this zip into
      ...\steamapps\common\ACE COMBAT 8\Game\Binaries\Win64\
  and say Yes to replace the files (your own survival.ini is kept).
Everyone in a session needs 0.73.82 (this patch or the players' patch): a 0.73.81 player is refused ("another build").

Please check:
1. Launch the game a few times, including when the main menu is slow to load: no crash. After a slow load the log
   (AC8SurvivalMode_lua.log) should have one line "tick: the game thread hadn't run the tick queued 10 s or more
   before ... queued again N times" and the game carries on.
2. Every key still works, a fraction of a second later at most: I (the info wall), O (the next player while DOWN),
   the item keys, and your test keys (Ctrl+END, Ctrl+8, ...).
3. Play as usual (solo and co-op): rounds, the STORE and the HUD as in 0.73.81.
Then send AC8SurvivalMode_lua.log, AC8SurvivalMode.log, AC8SurvivalMode_crumbs.log (and crumbs.prev after a crash) and
UE4SS.log as before.

Leaderboard: this patch changes the build's fingerprint (the log's first "leaderboard: ... build hash" line): send it
so it can be registered.
