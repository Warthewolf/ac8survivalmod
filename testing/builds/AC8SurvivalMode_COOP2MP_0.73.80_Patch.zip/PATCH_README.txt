AC8 Survival Mode COOP2MP 0.73.80 - patch (2026-11-04)
=====================================================
For: a 0.73.78 COOP2MP Online COOP install, with or without the 0.73.79 patch (this one replaces every Lua file).

What's new since 0.73.79:
- Less lag for the host late in a run: checking whether each enemy flight was still alive got slower with every flight
  ever spawned (6.6 ms a check by round 30, asked for every flight once a second); the answers are now kept and asked
  again a few at a time. In co-op, the airfield's landing menu is no longer searched for several times a second while
  you're down there. VALKA's hitches at her opener and her reveal are gone (her parts load in the break before her).
- The shuttle launch works every time again (rounds 17 and 30 of the last run fell back to a bomber raid). If a special
  ever can't start, another one comes instead, or a normal round from the start (never half of one).
- Specials come more evenly: the chance grows each round without one, one is sure after 4 such rounds, and every
  special comes once before any comes again. (Ace rounds only come in rounds without a special, so there are a few
  fewer of them.)
- Co-op:
  - The landing craft, the STORE's defences and the shuttle pad are the same objects on every game now (before, each
    game fought its own copy).
  - Your kills are your plane's on your own game too (your kill counts and pay as the host names them).
  - A player who quits or crashes mid-round holds the next spawns for 15 s at most (it was 50-80 s).
  - Other players' modded planes: you see their real plane if you have the same mod; if you don't, you see the stock
    plane it's built on (the Falken as an ADFX-02) instead of an AI F-16C. A modded paint you don't have shows as that
    plane's default paint, their emblems kept.
  - Landing craft and troops that get away no longer count as someone's kill.
  - Other players' launches show the moment you close your STORE.
- Leaderboard: a run refused because its build wasn't registered yet is kept and sent again at later game starts (for
  14 days) instead of being deleted.
- VALKA's first shot (her railgun from far away) can't hurt you even if it fires late; her own shots hurt as before.
- New settings in survival.ini: [specials] chance_step, max_gap, bag, swap; [coop] hold_lost_s, kill_callout,
  real_default; [coop.real_fallback] and [coop.real_paths] (any modded plane code); [coop.sync] standins; [hud.landing].
Not in this patch (it needs the next full build, runtime 0.32.24): the native log's lag fix, and showing another
player's weapons that your copy of their plane hasn't (a weapon mod, a changed loadout) as the nearest weapon of the
same kind. Until then those launches aren't shown, as in 0.73.79.

Install (the game closed):
  Copy the "ue4ss" folder from this zip into
      ...\steamapps\common\ACE COMBAT 8\Game\Binaries\Win64  and say Yes to replace the files (the Scripts folder's .lua files and config\survival.default.ini; your own
  survival.ini is kept, and the new settings are added to it, switched off, at the next start).
Everyone in a co-op session needs 0.73.80: a 0.73.79 player is refused ("another build").

Leaderboard: your runs count once this patch's fingerprint is registered; until then they're kept and sent again at
later game starts.
To undo: put back the Scripts folder and config\survival.default.ini from your 0.73.78 zip (and the 0.73.79 patch).
Problems: @voidcallsreaper on Discord.
