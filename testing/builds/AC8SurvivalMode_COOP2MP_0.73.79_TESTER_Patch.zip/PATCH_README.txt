AC8 Survival Mode COOP2MP 0.73.79 - TESTER patch (for Saint Alessia only, 2026-11-04)
=====================================================================================
Test keys in (the same keys as your 0.73.78 key list). Please don't pass this one on: your joiners use
AC8SurvivalMode_COOP2MP_0.73.79_Patch.zip (same version, so you link fine).

For: a 0.73.78 COOP2MP Online COOP install (the normal zip or your 0.73.78 TESTER zip, with or without the kill fix patch).

What's new since 0.73.78:
- Less lag and stutter: far fewer slow searches through the game's objects (the Alicorn's spawn, the Ladons, the airfield
  repairs, the menus, the shuttle take-off), VALKA's sounds loaded before her fight instead of during it.
- The Alicorn no longer dives once its ballast tanks are destroyed.
- The co-op kill fix (joiners' missiles finish enemies again; hits no longer lost to the host's health updates).
Not in this patch: the native runtime's part of the lag fix (it needs a full build); that comes with the next full zip.

Install (the game closed):
  Copy the "ue4ss" folder from this zip into
      ...\steamapps\common\ACE COMBAT 8\Game\Binaries\Win64\
  and say Yes to replace the files (only the Scripts folder's .lua files).
Everyone in a session needs 0.73.79 (this patch or the players' patch): a 0.73.78 player is refused ("another build").

Please check:
1. Stutter: force the Alicorn (Ctrl+5), the Ladons (Ctrl+4) and VALKA (Ctrl+8). Choppy or smooth? Any freeze when they appear?
2. The Alicorn: destroy all 4 ballast tanks. Does it still dive after that? (It shouldn't.)
3. Joiners: can they finish enemies with their missiles now?
Then send AC8SurvivalMode_lua.log, AC8SurvivalMode.log, AC8SurvivalMode_crumbs.log and UE4SS.log as before.

Leaderboard: this patch changes the build's fingerprint; runs with a test key pressed are never sent anyway.
To undo: put back the Scripts folder from your 0.73.78 zip.
Problems: @voidcallsreaper on Discord.
