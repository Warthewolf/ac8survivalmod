-- made by tools/build_survival.py from tools/menu_stock.py's finds: the game's main-menu page Survival's pages
-- copy (its class) and the game's main-menu page tables (Survival's pages go in them at start)
return {
    page_class = "WBP_Menu_MainTop_000_C",
    class_tables = { "/Game/Datatables/UI/Menu/MainMenu/DT_LiveMenuMainClassTable.DT_LiveMenuMainClassTable" },
}
