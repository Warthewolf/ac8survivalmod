-- sv_ladon.lua: the Ladons and the hit log.
-- Part of AC8 Survival Mode's runtime, run by main.lua in order (sv_core, sv_config, sv_rows, sv_ai, sv_hud, sv_sound, sv_spawn, sv_anomalies, sv_rounds, sv_ladon, sv_leaderboard, sv_alicorn, sv_amphib, sv_flights, sv_shop, sv_allies, sv_tactical, sv_main); a name
-- another part uses is a global of this mod's Lua state, its own helpers stay local (tools/lua_split.py).

---------------------------------------------------------------------------------------------------- ladon
-- CFG.specials.ladon; tools/survival_events.py LADON* builds the units (Mission 16's Ladon, parts and all), routes and
-- records. Ladon <Key> is unit SV_Unit_Ladon<Key> on DT_NPC row SV_Ladon_<Key>; each pass over the airfield adds one to
-- SV_LadonRun<Key>.
do
local KEYS = { "Kot", "Mishka" }

-- A Ladon's parts (its 25 objects: the body, the VLS launchers, the pulse cannon pods...), as SV_Spawn makes them
-- (spawningUnit is its unit then: SPC.ladonSpawn here, a co-op joiner's copies in sv_coop.lua): LADON_PARTS[unit].
-- The co-op run of 2026-10-30 (0.73.20), round 8: both Ladons shot down (their bodies "down" in the round probe) but
-- their parts lived on, so SV_UnitAlive (the unit's AliveChildAIGameObjects) never reached 0 and the round never ended
-- ("it still says both LADONs are alive"), and MISHKA's VLS fired on after its body was gone: four players down 0-4 s
-- after it, the host from 100 HP in one hit, all of it from BP_OP0045_ladn_VLS_L_Base
LADON_PARTS = {}
pcall(NotifyOnNewObject, "/Script/Live.LiveAIGameObject", function(o)
    local u = spawningUnit
    if not (u and u:find("^SV_Unit_Ladon")) then return end
    local l = LADON_PARTS[u]
    if not l or os.clock() - (l.at or 0) > 2 then l = { at = os.clock() }; LADON_PARTS[u] = l end   -- (a new spawn of it)
    if #l < 60 then l[#l + 1] = o end
end)

-- Ladon `p` (a body in planes) is down: its parts still up are finished off (no attacker: as a joiner's hit, which the
-- game takes). Every game, for its own copy. The number finished, or nil
function ladonPartsDown(p)
    local l = p and p.unit and LADON_PARTS[p.unit]
    if not l then return nil end
    local n, left = 0, 0
    for _, o in ipairs(l) do
        if valid(o) and o ~= p.obj then
            local okH, h = pcall(function() return o.HealthInternal end)
            if okH and type(h) == "number" and h > 0 then
                pcall(function() o:SetMinHealth(0.0) end)
                local ok = pcall(function() o:ModifyHealth(-(h / 10 + 1000), nil, true) end)
                local okA, h1 = pcall(function() return o.HealthInternal end)
                if not ok or (okA and type(h1) == "number" and h1 > 0) then
                    local gs = StaticFindObject("/Script/Engine.Default__GameplayStatics")
                    if valid(gs) then pcall(function() gs:ApplyDamage(o, 100000000.0, nil, nil, nil) end) end
                    okA, h1 = pcall(function() return o.HealthInternal end)
                end
                if okA and type(h1) == "number" and h1 > 0 then left = left + 1 else n = n + 1 end
            end
        end
    end
    log(string.format("special: %s's body down: %d of its %d parts still up finished off%s", p.unit, n, #l,
        left > 0 and string.format(", %d NOT (still up)", left) or ""))
    return n
end

-- Ladon `unit`'s body (its planes from `from`) seen and every one of them down: the round's own count of it
local function bodyDown(unit, from)
    local seen = false
    for i = from or 1, #planes do
        local p = planes[i]
        if p.unit == unit then
            seen = true
            if not p.down and valid(p.obj) then return false end
        end
    end
    return seen
end

-- At the main menu, before the level loads (the spawner caches the rows then): each Ladon's DT_NPC row, from
-- DT_SV_NpcRows, with its name, health and speed.
function SPC.ladonSetup()
    if SPC.ladonDone or not gameInstance() then return end
    local c = CFG.specials.ladon
    local npc, mine = loadObject(PROBE_TABLES[2].path), loadObject(c.npc_rows)
    SPC.ladonTries = (SPC.ladonTries or 0) + 1
    if not (npc and mine) then
        if SPC.ladonTries >= 20 then SPC.ladonDone = true; log("special: the Ladons' tables didn't load; no Ladon round") end
        return
    end
    SPC.ladonDone = true
    local n = 0
    for _, k in ipairs(KEYS) do
        local row = "SV_Ladon_" .. k
        local _, have = dtCall(npc, "FindRow", row)
        if have == nil then
            local _, r = dtCall(mine, "FindRow", row)
            if r ~= nil then dtCall(npc, "AddRow", row, r); _, have = dtCall(npc, "FindRow", row) end
        end
        if have ~= nil then
            n = n + 1
            local ok, err = pcall(function()
                have.MaxHealthDifference = c.health_add
                for _, f in ipairs({ "SpeedNormalCoefficient", "SpeedMaxCoefficient", "SpeedMinCoefficient", "SpeedTurnCoefficient" }) do
                    local v = have[f]
                    have[f] = ((type(v) == "number" and v > 0) and v or 1.0) * c.speed_x
                end
            end)
            if not ok then log("special: Ladon row " .. row .. ": health / speed NOT set: " .. tostring(err)) end
        end
        if type(SV_SetText) == "function" then SV_SetText(row, c.names[k] or k:upper()) end
    end
    SPC.ladonReady = n == #KEYS
    log(string.format("special: %d of %d Ladon rows in DT_NPC (%s; %+d HP, speeds x%.2f)", n, #KEYS,
        table.concat({ c.names.Kot, c.names.Mishka }, ", "), c.health_add, c.speed_x))
end

function SPC.ladonSpawn(now)
    local c, t = CFG.specials.ladon, CFG.hud.text
    if not (nativeReady() and SPC.ladonReady) then
        log("special: no Ladon round (" .. (SPC.ladonReady and "no native spawner" or "their rows aren't in") .. ")")
        return false
    end
    local s = D.special
    s.units, s.state, s.at, s.runs, s.planeFrom = {}, "run", now, 0, #planes + 1
    for _, k in ipairs(KEYS) do
        local unit = "SV_Unit_Ladon" .. k
        local r, was = SV_UnitAlive(unit), nil
        if r > 0 then was = true                     -- still up from before (a restart mid-round): this round's, then
        else spawningUnit = unit; r = SV_Spawn(unit); spawningUnit = nil end
        log(string.format("special: Ladon %s (%s): %s", c.names[k] or k, unit, r > 0 and (was and "still up, taken on" or "up") or
            ("not spawned (" .. (SV_ERR[r] or tostring(r)) .. ")")))
        if r > 0 then s.units[k] = { unit = unit, alive = true, runs = 0 } end
    end
    if not next(s.units) then return false end
    hudCallout(t.ladon_go, string.format(t.ladon_go_sub, c.names.Kot or "KOT", c.names.Mishka or "MISHKA"))
    log(string.format("special: round %d, the Ladons from the west", D.round))
    return true
end

function SPC.ladonsLeft(s)
    local n = 0
    for _, L in pairs(s.units or {}) do if L.alive then n = n + 1 end end
    return n
end

function SPC.ladonBusy(s) return s.state == "run" and SPC.ladonsLeft(s) > 0 end

-- Ladon `downKey` shot down: the other one, still up, is enraged (CFG.specials.ladon.rage; behaviour roadmap P7, "after
-- one Ladon dies the other changes route and volleys faster"; tools/re/BEHAVIOUR_DIRECTOR.md unit 9; their round stays
-- theirs alone, user 2026-10-25): its volleys every rage.volley_every_s, the next rage.first_s on (once you're in
-- range; its tell first, never in the same second: with the other's gap gone it had come with it, code review of unit
-- 9), and RE_SV_LadonRage<Key> sets its flag, so its next pass over the airfield ends on the tighter, faster rage
-- circuit (tools/survival_events.py LADON_RAGE: its PathFinish records pick the path by the flag; never a path changed
-- mid-way). Forwarded to co-op joiners (their copies are moved by the host's stream; harmless). The tell (its radio
-- call) to every player. Once a round.
function SPC.ladonRage(now, s, downKey)
    local c = CFG.specials.ladon
    local rg = c.rage
    if not (rg and rg.enabled) or s.raged then return false end
    for k2, L2 in pairs(s.units or {}) do
        if k2 ~= downKey and L2.alive and SV_UnitAlive(L2.unit) > 0 then       -- (both down in one second: no rage)
            s.raged, L2.rage, L2.rageAt = k2, true, now
            L2.volleyAt = now + math.max(1, tonumber(rg.first_s) or 0)
            -- (hotfix3: rg.circuit false: its circuit kept, the rage path isn't followed; CFG.specials.ladon.rage)
            local r = rg.circuit == false and -99 or (type(SV_Event) == "function" and SV_Event("RE_SV_LadonRage" .. k2) or -5)
            local name = c.names[k2] or k2:upper()
            if TELL then pcall(TELL.say, "ladon_rage", TELL.ALL) end
            log(string.format("special: Ladon %s enraged (%s down): volleys every %d s, the rage circuit from its next pass (RE_SV_LadonRage%s %s)",
                name, c.names[downKey] or downKey, tonumber(rg.volley_every_s) or c.volley_every_s, k2,
                r == 1 and "fired" or r == -99 and "not fired: rage.circuit false, it keeps its own circuit"
                or ("not fired: " .. tostring(SV_ERR and SV_ERR[r] or r))))
            return true
        end
    end
    return false
end

-- Every second: a pass over the airfield (its bombs), a Ladon shot down (its pay).
function SPC.ladonTick(now, s)
    if s.state ~= "run" or now < (s.nextAt or 0) then return end
    s.nextAt = now + 1
    local c, t = CFG.specials.ladon, CFG.hud.text
    local f = svFlags() or {}
    -- its health for its round, once its aircraft is up (HealthInternal: health x 10, as the shuttle's)
    local hx = math.min(c.health_max_x or 2.5, 1 + (c.health_per_round or 0) * math.max(0, D.round - CFG.specials.first))
    for i = s.planeFrom or 1, (s.scaledN or 0) < 2 and #planes or 0 do
        local p = planes[i]
        if hx > 1 and not p.down and not p.scaled and p.unit and p.unit:find("^SV_Unit_Ladon") and valid(p.obj) then
            local ok, h0 = pcall(function() return p.obj.HealthInternal end)
            if ok and type(h0) == "number" and h0 > 0 then        -- (not yet set on a fresh actor: next second)
                p.scaled, s.scaledN = true, (s.scaledN or 0) + 1
                local okW, err = pcall(function() p.obj.HealthInternal = math.floor(h0 * hx) end)
                log(string.format("special: %s health x%.2f for round %d (%s -> %s)%s", p.unit, hx, D.round, tostring(h0),
                    tostring(okW and p.obj.HealthInternal or "?"), okW and "" or (" (write failed: " .. tostring(err) .. ")")))
            end
        end
    end
    for k, L in pairs(s.units) do
        -- (patch ladon1: none after its first pass while volley_after_pass is false; see CFG.specials.ladon)
        if L.alive and now >= (L.volleyAt or s.at + 10) and (c.volley_after_pass ~= false or not L.passed) then
            local near
            for _, p in ipairs(planes) do
                if p.unit == L.unit and not p.down and valid(p.obj) and p.dist then near = math.min(near or p.dist, p.dist) end
            end
            if near and near <= c.volley_range_km then
                L.inRangeAt = L.inRangeAt or now                       -- (the first volley: once in range volley_warn_s)
                -- one Ladon's volley at a time, volley_gap_s apart (a friend's test of 2026-10-23: both came into range
                -- together and fired in the same second, and the player was down 20 s later): the other one waits.
                -- Enraged (the other one down: rage, P7) its own rage.volley_every_s / volley_warn_s and no gap (the
                -- other's last volley held a rage volley_every_s under it, and its first, up to 22 s: code review of
                -- unit 9); still one launcher a volley (both at once killed players in 9 s)
                local rg = L.rage and c.rage or nil
                local every = rg and tonumber(rg.volley_every_s) or c.volley_every_s
                local gap = rg and 0 or (c.volley_gap_s or c.volley_every_s / 2)
                local warn = rg and tonumber(rg.volley_warn_s) or (c.volley_warn_s or 0)
                if now - L.inRangeAt >= warn and now - (s.volleyAny or -1e9) >= gap then
                    L.volleyAt, s.volleyAny, s.volleyWho = now + every, now, c.names[k] or k
                    L.side = (L.side == "L") and "R" or "L"
                    local ev, first = "RE_SV_LadonVolley" .. k .. L.side, not L.volleySaid
                    local function volley()
                        local r = type(SV_Event) == "function" and SV_Event(ev) or "n/a"
                        HIT.sweepUntil = ((D and D.now) or now) + 6      -- (its missiles leave 1.5 s on: HIT.tick's sweep)
                        log(string.format("special: Ladon %s fires a launcher at you (%.1f km; %s %s)%s%s", c.names[k] or k, near, ev,
                            tostring(r), first and string.format(", one every %d s in range%s", every,
                            rg and "" or string.format(", %d s after the other's", gap)) or "", rg and ", enraged" or ""))
                    end
                    -- its tell first (behaviour roadmap P3, CFG.tells ladon_vls: "large aircraft has launched missile",
                    -- every player, as the volley's forwarded), the volley its lead_s after (0: with it; the hatch opens first)
                    if TELL then TELL.after("ladon_vls", TELL.ALL, volley) else volley() end
                    L.volleySaid = true
                end
            else
                L.inRangeAt = nil
            end
        end
        if L.alive then
            local runs = f["SV_LadonRun" .. k] or 0
            -- (patch ladon1) its pass count went down: only its appearance record sets it to 0, so the appearance
            -- fired again (and sent it back onto its route from the far west); count from here, or no pass after
            -- it would ever be counted (runs > L.runs)
            if runs < L.runs then
                L.resets = (L.resets or 0) + 1
                log(string.format("special: Ladon %s's pass count reset %d -> %d (its appearance fired again, %d so far; last volley %s)",
                    c.names[k] or k, L.runs, runs, L.resets, s.volleyWho and string.format("%s's %.0f s ago", s.volleyWho, now - (s.volleyAny or now)) or "none"))
                L.runs = runs
            end
            if now >= (L.posAt or 0) and (c.pos_log_s or 0) > 0 then   -- (patch ladon1) where it is, for its track
                L.posAt = now + c.pos_log_s
                for _, p in ipairs(planes) do
                    if p.unit == L.unit and not p.down and valid(p.obj) then
                        local okL, l = pcall(function() return p.obj:K2_GetActorLocation() end)
                        if okL and l then
                            log(string.format("special: Ladon %s at (%.1f, %.1f) km, alt %.1f km, %.1f km from the airfield; pass flag %d, passes %d%s",
                                c.names[k] or k, l.X / 100000, l.Y / 100000, l.Z / 100000,
                                math.sqrt((l.X - AIRFIELD.X) ^ 2 + (l.Y - AIRFIELD.Y) ^ 2) / 100000, runs, L.passes or 0,
                                L.passed and c.volley_after_pass == false and ", volleys off" or ""))
                        end
                        break
                    end
                end
            end
            -- (a count left from last time is reset by its appearance; a circuit takes minutes, so one pass in 30 s at
            -- most: a path that "finished" every frame once counted 30 a second and bombed every second, 2026-10-23)
            -- (0.73.69) or by distance: after a lap it circles in its unit area on the airport, and no PathFinish
            -- counts its passes then. A pass: within 2.5 km of the airfield after being 5 km or more out.
            local near = false
            if L.passes and L.passes >= 1 then
                for _, p in ipairs(planes) do
                    if p.unit == L.unit and not p.down and liveAddr(p.obj) then
                        local okL, l = pcall(function() return p.obj:K2_GetActorLocation() end)
                        if okL and l then
                            local dkm = math.sqrt((l.X - AIRFIELD.X) ^ 2 + (l.Y - AIRFIELD.Y) ^ 2) / 100000
                            if dkm >= 5 then L.armed = true
                            elseif dkm <= 2.5 and L.armed then near = true end
                        end
                        break
                    end
                end
            end
            if now - s.at >= 5 and (runs > L.runs or near) and now - (L.bombAt or 0) >= 30 then
                L.armed = false
                L.runs, L.bombAt, s.runs = math.max(runs, L.runs), now, (s.runs or 0) + 1
                L.passes = (L.passes or 0) + 1
                if not L.passed and c.volley_after_pass == false then
                    log(string.format("special: Ladon %s: no more volleys after its first pass (volley_after_pass false)", c.names[k] or k))
                end
                L.passed = true
                local dmg = c.bomb_damage + (c.bomb_per_round or 0) * math.max(0, D.round - CFG.specials.first)
                if CFG.airfield.enabled and not AF.down then AF.bomb = AF.bomb + dmg end
                hudCallout(string.format(t.ladon_run, c.names[k] or k), t.ladon_run_sub)
                log(string.format("special: Ladon %s's pass over the airfield (%d): -%d%s", c.names[k] or k, runs, dmg,
                    L.rage and string.format(" (enraged %.0f s ago)", now - (L.rageAt or now)) or ""))
            end
            local n, gone = SV_UnitAlive(L.unit), false
            if n >= 0 then L.errs = 0 else L.errs = (L.errs or 0) + 1 end
            if n == -7 or (L.errs or 0) >= 20 then           -- off the phase's list, or unreadable for 20 s
                local flying = false                          -- (code review of 2026-10-23: -7 paid, other errors held
                for _, p in ipairs(planes) do                 -- the round for good)
                    if p.unit == L.unit and not p.down and valid(p.obj) then flying = true end
                end
                if not flying then
                    L.alive, gone, s.escaped = false, true, true
                    log(string.format("special: Ladon %s gone without being shot down (SV_UnitAlive %d); no pay", c.names[k] or k, n))
                end
            end
            if n > 0 and not gone and bodyDown(L.unit, s.planeFrom) then   -- (its body down, parts still up: down)
                log(string.format("special: Ladon %s's body is down, %d of its unit still up (its parts): counted down", c.names[k] or k, n))
                n = 0
            end
            if n == 0 and not gone then
                L.alive = false
                local pay = c.reward + (c.reward_per_round or 0) * D.round
                addCredits(pay, "Ladon " .. (c.names[k] or k) .. " down")
                LB.stat("air", 1)
                hudCallout(string.format(t.ladon_down, c.names[k] or k), string.format(t.ladon_down_sub, pay))
                log(string.format("special: round %d, Ladon %s down %.0f s after it appeared", D.round, c.names[k] or k, now - s.at))
                pcall(SPC.ladonRage, now, s, k)              -- (the other one enraged: P7)
            end
        end
    end
    if SPC.ladonsLeft(s) == 0 then s.state = "done"; LB.special("ladon", not s.escaped, now - s.at) end
end
end

---------------------------------------------------------------------------------------------------- hits on the player
-- A friend's run ended 20 s after both Ladons' volleys and the log couldn't say what hit them (2026-10-23): the
-- player's health is read every tick and a drop is logged (at most once a second, the drops between added up) with the
-- enemy missiles near the player then (every LiveMissile but the player's, tracked from its creation; one that hit is
-- gone the tick after, so the last distance it was seen at counts) and the nearest enemy aircraft. No missile near:
-- a gun, the Ladons' pulse cannons, a SAM's blast or a collision. The Ladons' VLS missiles are toned down here as they
-- appear (CFG.specials.ladon.missile_*): from their class default, so a missile seen twice isn't cut twice.
HIT = { new = {}, msl = {} }
pcall(NotifyOnNewObject, "/Script/Live.LiveMissile", function(o) if #HIT.new < 200 then HIT.new[#HIT.new + 1] = o end end)
do
local LADON_MSL = "BP_wp_vls_ladon"
local LADON_CDO = "/Game/Blueprints/Weapons/MSL/NPC/Vls/Ladon/BP_wp_vls_ladon.Default__BP_wp_vls_ladon_C"
local LADON_CERTAIN = "BP_wp_vls_certain_ladon"
local function short(o)                                    -- "BP_wp_vls_ladon" from "... .BP_wp_vls_ladon_C_2147..."
    local n = nameOf(o):match("([%w_]+)$") or "?"
    return (n:gsub("_C_%d+$", ""):gsub("_C$", ""))
end
local function at(o)
    local ok, v = pcall(function() local l = o:K2_GetActorLocation(); return { X = l.X, Y = l.Y, Z = l.Z } end)
    return ok and v or nil
end
local function owner(o)                                    -- who fired it (its owner, else its instigator) and that actor, or nil
    for _, f in ipairs({ function() return o:GetOwner() end, function() return o.Instigator end }) do
        local ok, w = pcall(f)
        if ok and valid(w) then return short(w), w end
    end
    return nil
end

-- its turn rates from `base` (the class default) x missile_turn_x (user, 2026-10-29: "make their missiles turn less
-- faster, they're almost unavoidable"): "a -> b deg/s" for the log
local function slower(o, base)
    local x = tonumber(CFG.specials.ladon.missile_turn_x) or 1
    local r0 = base.MaxRotationAngle
    o.MaxRotationAngle = r0 * x
    pcall(function()                                       -- (its turn before it has a lock, where it has one)
        local n0 = base.MaxRotationAngleNotCaptured
        if type(n0) == "number" and n0 > 0 then o.MaxRotationAngleNotCaptured = n0 * x end
    end)
    return string.format("%.0f -> %.0f deg/s", r0, o.MaxRotationAngle)
end

local function nerf(o)
    local c = CFG.specials.ladon
    if not valid(HIT.cdo) then HIT.cdo = StaticFindObject(LADON_CDO) end
    local base = valid(HIT.cdo) and HIT.cdo or o
    local ok, err = pcall(function()
        local d0, a0 = base.damage, base.MaxHomingAngle
        o.damage = tonumber(c.missile_damage) or d0
        o.MaxHomingAngle = a0 * (c.missile_homing_x or 1)
        local turn = slower(o, base)
        if not HIT.nerfSaid then
            HIT.nerfSaid = true
            log(string.format("hits: the Ladons' missile %s toned down: damage %.1f -> %.1f, homing cone %.0f -> %.0f deg, turn %s (from %s)",
                LADON_MSL, d0, o.damage, a0, o.MaxHomingAngle, turn, base == o and "the missile itself" or "its class default"))
        end
    end)
    if not ok and not HIT.nerfErr then HIT.nerfErr = true; log("hits: the Ladons' missile NOT toned down: " .. tostring(err)) end
end

-- Mission 16's scripted sure kill, BP_wp_vls_certain_ladon (hard rule 36): Survival's volleys fire the ordinary
-- missile, but the Ladon's own fire control can pick it too (a run of 2026-10-24: one shot down the player from 198 HP
-- with three airframe upgrades, 15 s after a volley). Each one is made the ordinary missile, as toned down above
-- (missile_damage; homing cone and turn rate from BP_wp_vls_ladon's class default). Never destroyed: a missile destroyed from Lua stays
-- counted in flight and on the missile alert, and the game crashed (the ECM burst, 2026-10-25).
local function certain(o)
    local c = CFG.specials.ladon
    if not valid(HIT.cdo) then HIT.cdo = StaticFindObject(LADON_CDO) end
    local ok, err = pcall(function()
        local d0, a0 = o.damage, o.MaxHomingAngle
        local d1 = tonumber(c.missile_damage) or 10
        local a1 = valid(HIT.cdo) and HIT.cdo.MaxHomingAngle * (c.missile_homing_x or 1) or a0
        o.damage, o.MaxHomingAngle = d1, math.min(a0, a1)
        local turn = slower(o, valid(HIT.cdo) and HIT.cdo or o)
        if not HIT.certainSaid then
            HIT.certainSaid = true
            log(string.format("hits: the Ladons' sure-kill missile BP_wp_vls_certain_ladon made an ordinary one: damage %.1f -> %.1f, homing cone %.0f -> %.0f deg, turn %s",
                d0, o.damage, a0, o.MaxHomingAngle, turn))
        end
    end)
    if not ok and not HIT.certainErr then HIT.certainErr = true; log("hits: the Ladons' sure-kill missile NOT toned down: " .. tostring(err)) end
end

-- what's near the player now: "missiles: ...; enemies: ..."
local function around(me, now)
    local ms = {}
    for _, m in ipairs(HIT.msl) do
        if m.d and m.d <= 800 and now - (m.seen or -1e9) <= 0.6 then ms[#ms + 1] = m end
    end
    table.sort(ms, function(a, b) return a.d < b.d end)
    local mt = {}
    for i = 1, math.min(3, #ms) do
        local m = ms[i]
        mt[#mt + 1] = string.format("%s %.0f m%s%s", m.name, m.d, m.from and (" from " .. m.from) or "",
            liveAddr(m.obj) and "" or " (gone: it hit)")
    end
    local es = {}
    for _, p in ipairs(planes) do
        if not p.down and p.dist and p.dist <= 8 and valid(p.obj) then
            local v = at(p.obj)
            if v then es[#es + 1] = { name = p.unit or short(p.obj), d = km(v, me) } end
        end
    end
    table.sort(es, function(a, b) return a.d < b.d end)
    local et = {}
    for i = 1, math.min(3, #es) do et[#et + 1] = string.format("%s %.2f km", es[i].name, es[i].d) end
    return "missiles near: " .. (#mt > 0 and table.concat(mt, ", ") or "none (gun / pulse cannon / blast / collision?)") ..
        "; nearest enemies: " .. (#et > 0 and table.concat(et, ", ") or "none within 8 km")
end

function HIT.reset()
    HIT.new, HIT.msl, HIT.h, HIT.pawn, HIT.sum = {}, {}, nil, nil, nil
    HIT.ladonUntil, HIT.ladonSweepAt = nil, nil
end

-- every tick in a run (now: the round clock)
function HIT.tick(pc, now)
    local new = HIT.new
    HIT.new = {}
    -- Weapons are pooled (LiveWeaponBase is a LiveObjectPoolItem: the co-op fire research of 2026-10-29), so a volley's
    -- reused missiles never come in as new objects: for sweep_s after each volley (HIT.sweepUntil, sv_ladon's volley)
    -- every Ladon missile up is toned down again (from the class default, so twice is the same as once)
    -- Also every 0.5 s while a Ladon is up and 40 s after the last: its own fire control fires the sure kill too, pooled,
    -- outside Survival's volleys (the co-op run of 2026-10-30, round 8: four players down within 4 s of Ladon MISHKA's
    -- end, the host from 100 HP in one hit, all of it from BP_OP0045_ladn_VLS_L_Base, its volley 39 s before)
    if now then
        for _, p in ipairs(planes or {}) do
            if not p.down and ((p.unit or ""):find("Ladon", 1, true) or (p.name or ""):find("_ladn_", 1, true)) then
                HIT.ladonUntil = now + 40
                break
            end
        end
    end
    local volleyOn = HIT.sweepUntil and now and now < HIT.sweepUntil
    local ladonOn = HIT.ladonUntil and now and now < HIT.ladonUntil and now >= (HIT.ladonSweepAt or 0)
    if volleyOn or ladonOn then
        if ladonOn then HIT.ladonSweepAt = now + 0.5 end
        local n = 0
        for cls, fn in pairs({ [LADON_MSL .. "_C"] = nerf, [LADON_CERTAIN .. "_C"] = certain }) do
            for _, o in ipairs(FindAllOf(cls) or {}) do
                if valid(o) and not short(o):find("^Default__") then
                    if fn == certain then
                        local okD, d = pcall(function() return o.damage end)
                        if okD and type(d) == "number" and d > (tonumber(CFG.specials.ladon.missile_damage) or 10) + 0.5 then
                            HIT.certainCaught = (HIT.certainCaught or 0) + 1
                            if now - (HIT.certainCaughtSaid or -1e9) >= 60 then
                                HIT.certainCaughtSaid = now
                                log(string.format("hits: a Ladon's sure-kill missile caught at damage %.0f, made ordinary (%d so far; %s)",
                                    d, HIT.certainCaught, volleyOn and "a volley's" or "its own fire control's"))
                            end
                        end
                    end
                    fn(o); n = n + 1
                end
            end
        end
        if volleyOn and n > (HIT.sweepN or 0) then HIT.sweepN = n end
    elseif HIT.sweepUntil and not volleyOn then
        if not HIT.sweepSaid then
            HIT.sweepSaid = true
            log(string.format("hits: a Ladon volley's missiles toned down as they flew (up to %d at once, pooled ones too)", HIT.sweepN or 0))
        end
        HIT.sweepUntil, HIT.sweepN = nil, nil
    end
    for _, o in ipairs(new) do                             -- the new missiles: enemies' tracked, the Ladons' toned down
        if liveAddr(o) then                                -- (hotfix2: caught a tick ago; not valid(), sv_core liveAddr)
            local n = short(o)
            if not n:find("^BP_plwp_") and not n:find("^Default__") then
                if n == LADON_MSL then nerf(o) elseif n == LADON_CERTAIN then certain(o) end
                if #HIT.msl >= 60 then table.remove(HIT.msl, 1) end
                HIT.msl[#HIT.msl + 1] = { obj = o, name = n, born = now }
            end
        end
    end
    local pawn = pc and pc.Pawn
    if not valid(pawn) then return end
    local me = at(pawn)
    local keep = {}
    for _, m in ipairs(HIT.msl) do                         -- where each one is (kept 2 s after it's gone)
        if liveAddr(m.obj) and now - m.born < 30 then     -- (hotfix2: not valid(), sv_core liveAddr)
            if not m.from then                             -- (its shooter's address: which plane, for the measurements)
                local nm, w = owner(m.obj)
                m.from = nm
                if w then m.fromAddr = addrOf(w) end
            end
            local v = me and at(m.obj)
            if v then m.d, m.seen = km(v, me) * 1000, now end
            keep[#keep + 1] = m
        elseif now - (m.seen or m.born) < 2 then keep[#keep + 1] = m end
    end
    HIT.msl = keep
    local okA, addr = pcall(function() return tostring(pawn:GetAddress()) end)
    if not okA then addr = nameOf(pawn) end
    if addr ~= HIT.pawn then HIT.pawn, HIT.h, HIT.sum = addr, nil, nil end    -- (a new aircraft: a restart)
    local ok, h = pcall(function() return pawn.HealthInternal end)
    if not ok or type(h) ~= "number" then return end
    local last = HIT.h
    HIT.h = h
    if last and h < last then
        if not HIT.sum then HIT.sum, HIT.n, HIT.near = 0, 0, me and around(me, now) or "?" end   -- (as it was at the first)
        HIT.sum, HIT.n = HIT.sum + (last - h), HIT.n + 1
        pcall(STATS.hit, now, (last - h) / 10, pawn)     -- (each drop by its source: the measurements, sv_stats.lua)
    end
    if HIT.sum and now - (HIT.logged or -1e9) >= 1 then
        local okM, maxHp = pcall(function() return pawn.MaxHealth end)
        local pct = (okM and type(maxHp) == "number" and maxHp > 0) and string.format("%d%%", math.floor(h / 10 / maxHp * 100 + 0.5)) or "?"
        local s = D and D.special
        local vol = (s and s.volleyAny and now - s.volleyAny < 60) and string.format("; Ladon %s's volley %.0f s ago", s.volleyWho or "?", now - s.volleyAny) or ""
        log(string.format("hit: -%.0f HP in %d hit%s, health now %s (%.0f HP)%s; %s%s", HIT.sum / 10, HIT.n, HIT.n == 1 and "" or "s",
            pct, h / 10, h <= 0 and ", SHOT DOWN" or "", HIT.near, vol))
        HIT.logged, HIT.sum = now, nil
    end
end
end
