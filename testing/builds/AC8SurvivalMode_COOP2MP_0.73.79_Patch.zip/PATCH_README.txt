AC8 Survival Mode COOP2MP 0.73.79 - patch (2026-11-04)
======================================================
For: a 0.73.78 COOP2MP Online COOP install (AC8SurvivalMode_COOP2MP_0.73.78_Online_COOP.zip, with or without the kill
fix patch).

What's new since 0.73.78:
- Less lag and stutter: far fewer slow searches through the game's objects (the Alicorn's spawn, the Ladons, the airfield
  repairs, the menus, the shuttle take-off), VALKA's sounds loaded before her fight instead of during it.
- The Alicorn no longer dives once its ballast tanks are destroyed.
- The co-op kill fix (joiners' missiles finish enemies again; hits no longer lost to the host's health updates).

Install (everyone, host and joiners; the game closed):
  Copy the "ue4ss" folder from this zip into
      ...\steamapps\common\ACE COMBAT 8\Game\Binaries\Win64\
  and say Yes to replace the files (only the Scripts folder's .lua files).
The version is now 0.73.79-coop2mp.80: everyone in a session needs this patch (a 0.73.78 player is refused).

Leaderboard: the patch changes the build's fingerprint, so runs show NOT ACCEPTED until the new build hash is registered
(the first line of AC8SurvivalMode.log after starting the game: "leaderboard: the game started: build hash ...").
To undo: put back the Scripts folder from the 0.73.78 zip.
Problems: send UE4SS.log, AC8SurvivalMode.log and AC8SurvivalMode_lua.log to @voidcallsreaper on Discord.
