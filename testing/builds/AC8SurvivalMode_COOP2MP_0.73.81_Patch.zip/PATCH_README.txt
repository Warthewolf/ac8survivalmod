AC8 Survival Mode COOP2MP 0.73.81 - patch (2026-11-04)
=====================================================
For: a 0.73.78 COOP2MP Online COOP install, with or without the 0.73.79 / 0.73.80 patches (this one replaces every Lua
file and config\survival.default.ini). Everything in 0.73.80's change log is in it too.

What's new since 0.73.80:
- Spaceport Assault: every WASP you sink sends 4 TU-160s at the airfield 6 s later ("TU-160S INBOUND / FROM THE NORTH"
  or "SOUTH": the groups come from the north and the south in turn). They fly in over the runway and bomb it, show on
  the minimap and pay as heavy bombers, and the round ends only once they're down too. The game has one 4-bomber flight,
  so if another Wasp goes down while 4 Tu-160s are still up, the next 4 come as soon as those are shot down. None in the
  retake or once the spaceport is captured (and a capture sends the ones up home with the fighters). Settings:
  [specials.spaceport.tu160] in survival.ini (group size, delay, directions).
- Heavy bombers (any bomber raid): when a Tu-95 / Tu-160 flight's lead is shot down first, the next one now takes over
  its bombing route every time (it could be lost right after the flight appeared, and the rest never bombed).

Install (the game closed):
  Copy the "ue4ss" folder from this zip into
      ...\steamapps\common\ACE COMBAT 8\Game\Binaries\Win64\
  and say Yes to replace the files (your own survival.ini is kept; new settings are added to it, switched off).
Everyone in a co-op session needs 0.73.81: a 0.73.80 player is refused ("another build").
Problems: @voidcallsreaper on Discord.
