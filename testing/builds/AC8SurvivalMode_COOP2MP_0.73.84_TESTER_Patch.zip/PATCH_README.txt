AC8 Survival Mode COOP2MP 0.73.84 - TESTER patch (for Saint Alessia only, 2026-11-05)
======================================================================================
Test keys in (the same keys as your 0.73.78 key list). Please don't pass this one on: your joiners use
AC8SurvivalMode_COOP2MP_0.73.84_Patch.zip (same version, so you link fine).

For: a 0.73.78 COOP2MP Online COOP install, with or without the 0.73.79 - 0.73.83 patches (this one replaces every Lua
file and config\survival.default.ini). Everything in 0.73.83's change log is in it too.

What's new since 0.73.83:
- Crash on quit fixed (Shazzy, 2026-11-04, round 24): with the GUN upgrade bought, quitting the mission could crash the
  game. Survival kept the gun's settings object to raise its damage, and on the way out it put the stock damage back
  into it, but by then the game had sometimes already freed that object with the level, and the write crashed. Most
  quits got there first, which is why it only crashed sometimes. Survival now only touches it while the game still
  holds it, and remembers the gun's stock damage for the whole session, so an upgrade never carries into the next run.
- The same guard for two other things kept between levels: VALKA's red sky (put back at the end of her fight) and the
  Ladon missile's settings (its damage and turn rate are toned down from them).
- The Comona Defense shuttle pad: after a shuttle round, quitting and starting a new run could crash the next run's first
  shuttle round (it tried to bring back the old level's hidden pad). The old pad is now forgotten with its level; a
  restart still brings it back as before.
- Quitting during VALKA's song could leave the game's music muted (the unmute couldn't be sent while the level was
  closing). It's now sent again as soon as the next Survival level starts. The main menu and the hangar before that
  may still be quiet (restarting the game also clears it); the full fix needs the next full build.

Install (the game closed):
  Copy the "ue4ss" folder from this zip into
      ...\steamapps\common\ACE COMBAT 8\Game\Binaries\Win64\
  and say Yes to replace the files (your own survival.ini is kept).
Everyone in a session needs 0.73.84 (this patch or the players' patch): a 0.73.83 player is refused ("another build").

Please check:
1. Buy the GUN upgrade, then Quit Mission (a few times over the session): no crash. The log line "upgrades: 1 gun
   class default gone with the level: forgotten, not touched" may show on a quit; that's the fix at work.
2. After a quit, start a new run: the gun upgrade starts from stock again (its first "upgrades: gun tier 1" line says
   damage 15.000 -> ...).
3. If a shuttle round comes, then quit and start a new run until another shuttle round: no crash, and the pad is up.
4. Everything from 0.73.83's list still holds (rejoin radar, past the Alicorn round, long runs, keys).
Then send AC8SurvivalMode_lua.log, AC8SurvivalMode.log, AC8SurvivalMode_crumbs.log (and crumbs.prev after a crash) and
UE4SS.log as before.

Leaderboard: this patch changes the build's fingerprint (the log's first "leaderboard: ... build hash" line): send it
so it can be registered.
