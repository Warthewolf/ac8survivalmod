AC8 Survival Mode COOP2MP 0.73.78 - co-op kill fix patch (2026-11-04)
=======================================================================
For: the 0.73.78 COOP2MP Online COOP build only (AC8SurvivalMode_COOP2MP_0.73.78_Online_COOP.zip).

Fixes: in co-op, enemies would drop to 1 HP on a joiner's screen and only the host could kill them
("dumping 6+ missiles into them"). A joiner's finishing missile is now sent to the host, and hits are
no longer lost when the host's health update arrives at the same moment.

Install (everyone, host and joiners; the game closed):
  Copy the "ue4ss" folder from this zip into
      ...\steamapps\common\ACE COMBAT 8\Game\Binaries\Win64\
  and say Yes to replace the file. It replaces one file:
      ue4ss\Mods\AC8SurvivalMode\Scripts\sv_coop.lua

The version stays 0.73.78-coop2mp.79, so patched and unpatched players can still play together, but a
joiner needs the patch for their own kills to work.

Leaderboard: the patch changes the build's fingerprint, so runs show NOT ACCEPTED until the new hash is
registered on the leaderboard's /admin page (the first line of AC8SurvivalMode.log after starting the
game: "leaderboard: the game started: build hash ...").

To undo: put back sv_coop.lua from the original 0.73.78 zip.
Problems: send UE4SS.log, AC8SurvivalMode.log and AC8SurvivalMode_lua.log to @voidcallsreaper on Discord.
