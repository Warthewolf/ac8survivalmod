AC8 Survival Mode COOP2MP 0.73.81 - TESTER patch (for Saint Alessia only, 2026-11-04)
======================================================================================
Test keys in (the same keys as your 0.73.78 key list). Please don't pass this one on: your joiners use
AC8SurvivalMode_COOP2MP_0.73.81_Patch.zip (same version, so you link fine).

For: a 0.73.78 COOP2MP Online COOP install, with or without the 0.73.79 / 0.73.80 patches (this one replaces every Lua
file and config\survival.default.ini). Everything in 0.73.80's change log is in it too.

What's new since 0.73.80:
- Spaceport Assault: every WASP you sink sends 4 TU-160s at the airfield 6 s later ("TU-160S INBOUND / FROM THE NORTH"
  or "SOUTH": the groups come from the north and the south in turn). They fly in over the runway and bomb it, show on
  the minimap and pay as heavy bombers, and the round ends only once they're down too. The game has one 4-bomber flight,
  so if another Wasp goes down while 4 Tu-160s are still up, the next 4 come as soon as those are shot down. None in the
  retake or once the spaceport is captured (and a capture sends the ones up home with the fighters). Settings:
  [specials.spaceport.tu160] in survival.ini (group size, delay, directions).
- Heavy bombers (any bomber raid): when a Tu-95 / Tu-160 flight's lead is shot down first, the next one now takes over
  its bombing route every time (it could be lost right after the flight appeared, and the rest never bombed).

Install (the game closed):
  Copy the "ue4ss" folder from this zip into
      ...\steamapps\common\ACE COMBAT 8\Game\Binaries\Win64\
  and say Yes to replace the files (your own survival.ini is kept; new settings are added to it, switched off).
Everyone in a session needs 0.73.81 (this patch or the players' patch): a 0.73.80 player is refused ("another build").

Please check (Ctrl+END forces the Spaceport Assault next round):
1. Sink a Wasp: 4 Tu-160s about 6 s later, called out with their side. Do they reach the runway and bomb it?
2. Sink a second Wasp while they're still up: the next 4 should come only once you've shot the first 4 down, from the
   other side.
3. Shoot the lead Tu-160 of a group first: do the other three still fly over the runway and bomb?
4. The round should end only once every Tu-160 is down. Co-op: do joiners see them, and get no pay for ones the host's
   capture sent home?
Then send AC8SurvivalMode_lua.log, AC8SurvivalMode.log, AC8SurvivalMode_crumbs.log and UE4SS.log as before.

Leaderboard: this patch changes the build's fingerprint (the log's first "leaderboard: ... build hash" line): send it
so it can be registered.
Problems: @voidcallsreaper on Discord.
